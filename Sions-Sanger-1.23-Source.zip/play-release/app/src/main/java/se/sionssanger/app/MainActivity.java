package se.sionssanger.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_JSON = 1201;
    private static final int SAVE_JSON = 1202;
    private WebView webView;
    private SionsTvServer tvServer;
    private SionsAudio audio;
    private SionsScore score;
    private SionsBackup backup;
    private SionsSmartImport smartImport;
    private ValueCallback<Uri[]> pendingFiles;
    private String pendingExport;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,45,73));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,45,73));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(245,240,231));
        setContentView(webView);
        audio = new SionsAudio(this);
        se.sabbath.tv.TvLink.attach(this,webView);
        tvServer = new SionsTvServer(this);
        tvServer.start();
        score = new SionsScore(this, webView);
        backup = new SionsBackup(this, webView);
        smartImport = new SionsSmartImport(this, webView, audio, score, backup);
        tvServer.setScores(score);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        webView.addJavascriptInterface(new AppBridge(), "SionsAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri url = request.getUrl();
                return !("file".equalsIgnoreCase(url.getScheme()) &&
                    url.toString().startsWith("file:///android_asset/"));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> result, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = result;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json","text/plain","application/octet-stream"});
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                try { startActivityForResult(i, PICK_JSON); }
                catch (Exception e) { pendingFiles.onReceiveValue(null); pendingFiles = null; return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AppBridge {
        @JavascriptInterface public void smartImport(String catalogue) { if(smartImport!=null)smartImport.pick(catalogue); }

        @JavascriptInterface public void backupExport(String state) { if(backup!=null)backup.export(state); }
        @JavascriptInterface public void backupImport() { if(backup!=null)backup.importBackup(); }

        @JavascriptInterface public void scorePick(String number) { if(score!=null)score.pick(number); }
        @JavascriptInterface public String scoreInfo(String number) { return score==null?"{}":score.info(number); }
        @JavascriptInterface public String scorePage(String number,int page) { return score==null?"":score.pageData(number,page); }
        @JavascriptInterface public String scoreXml(String number) { return score==null?"":score.xml(number); }
        @JavascriptInterface public void scoreRemove(String number) { if(score!=null)score.remove(number); }

        @JavascriptInterface public void audioTargetTv(boolean enabled) { audio.target(enabled); }
        @JavascriptInterface public void audioImport() { audio.pick(""); }
        @JavascriptInterface public void audioImportFor(String n) { audio.pick(n); }
        @JavascriptInterface public String audioList() { return audio.list(); }
        @JavascriptInterface public String audioStatus() { return audio.status(); }
        @JavascriptInterface public void audioPlay(String n) { audio.play(n); }
        @JavascriptInterface public void audioPause() { audio.pause(); }
        @JavascriptInterface public void audioStop() { audio.stop(); }
        @JavascriptInterface public void audioSeek(String n, double seconds) { audio.seek(n,seconds); }
        @JavascriptInterface public void audioAssign(String n, String source) { audio.assign(n,source); }
        @JavascriptInterface public String audioCues(String n) { return audio.cues(n); }
        @JavascriptInterface public void audioCue(String n, int verse, double seconds) { audio.cue(n,verse,seconds); }
        @JavascriptInterface public void audioClearCues(String n) { audio.clearCues(n); }

        @JavascriptInterface public void tvStop() { if(audio!=null)audio.pause();se.sabbath.tv.TvLink.stop(MainActivity.this); }
        @JavascriptInterface public void tvConnect() {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent().setComponent(new android.content.ComponentName(
                        "se.churchshow.tvbridge", "se.churchshow.tvbridge.MainActivity")).putExtra("start", true));
                } catch (android.content.ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Installera Sabbath TV – mobilbrygga först", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public String tvAddress() {
            return tvServer == null ? "" : tvServer.getUrl();
        }
        @JavascriptInterface public String tvCode() {
            return tvServer == null ? "" : tvServer.getCode();
        }
        @JavascriptInterface public void tvUpdate(String value) {
            if (tvServer != null) tvServer.update(value);
            try {
                org.json.JSONObject v = new org.json.JSONObject(value);
                org.json.JSONArray lines = v.optJSONArray("lines");
                StringBuilder words = new StringBuilder();
                if(lines!=null) for(int i=0;i<lines.length();i++){
                    if(i>0) words.append("\n");
                    words.append(lines.optString(i));
                }
                org.json.JSONArray people=v.optJSONArray("authors");
                StringBuilder credits=new StringBuilder();
                if(people!=null)for(int i=0;i<people.length();i++){
                    String author=people.optString(i).trim();
                    if(author.isEmpty())continue;
                    if(credits.length()>0)credits.append(" • ");
                    credits.append(author);
                }
                org.json.JSONObject slide=new org.json.JSONObject()
                    .put("source","sions-sanger")
                    .put("title",v.optString("title"))
                    .put("songNumber",v.optString("number"))
                    .put("credits",credits.toString())
                    .put("verse",v.optString("section"))
                    .put("verseIndex",v.optInt("index",0)+1)
                    .put("verseTotal",v.optInt("total",0))
                    .put("text",words.toString())
                    .put("label",v.optString("section"))
                    .put("wholeVerse",true)
                    .put("font",v.optDouble("font",100))
                    .put("blank",v.optBoolean("blank"));
                se.sabbath.tv.TvLink.slide(MainActivity.this,slide.toString());
            } catch(Exception ignored) {}
        }
        @JavascriptInterface public void tvCopy(String value) {
            runOnUiThread(() -> {
                android.content.ClipboardManager clipboard =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Sions Sånger TV", value));
                Toast.makeText(MainActivity.this, "TV-adress kopierad", Toast.LENGTH_SHORT).show();
            });
        }
        @JavascriptInterface public void tvKeepAwake(boolean enabled) {
            runOnUiThread(() -> {
                if (enabled) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }
        @JavascriptInterface public void tvFullscreen(boolean enabled) {
            runOnUiThread(() -> {
                if (enabled) {
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
                    getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
                } else {
                    getWindow().getDecorView().setSystemUiVisibility(0);
                    setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                }
            });
        }
        @JavascriptInterface public void saveJson(String json) {
            runOnUiThread(() -> {
                pendingExport = json;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE,"Sions_Sanger_alla_sanger.json");
                try { startActivityForResult(i, SAVE_JSON); }
                catch (Exception e) { pendingExport = null; Toast.makeText(MainActivity.this,"Kan inte öppna filväljaren",Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == SionsSmartImport.PICK) { if(smartImport!=null)smartImport.result(resultCode,data); return; }
        if(requestCode == SionsBackup.SAVE || requestCode == SionsBackup.RESTORE) { if(backup!=null)backup.result(requestCode,resultCode,data); return; }
        if(requestCode == SionsAudio.PICK) { audio.result(resultCode, data); return; }
        if(requestCode == SionsScore.PICK) { score.result(resultCode, data); return; }
        if (requestCode == PICK_JSON) {
            if (pendingFiles == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    android.content.ClipData clip = data.getClipData();
                    results = new Uri[clip.getItemCount()];
                    for (int j=0;j<clip.getItemCount();j++) results[j] = clip.getItemAt(j).getUri();
                } else if (data.getData() != null) {
                    results = new Uri[]{data.getData()};
                }
            }
            pendingFiles.onReceiveValue(results);
            pendingFiles = null;
        } else if (requestCode == SAVE_JSON) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingExport != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new java.io.IOException("No output stream");
                    out.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"JSON-filen sparad",Toast.LENGTH_SHORT).show();
                } catch (Exception e) { Toast.makeText(this,"Kunde inte spara JSON",Toast.LENGTH_LONG).show(); }
            }
            pendingExport = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("if (!(window.sionsTvBack && window.sionsTvBack())) { window.sionsGoBack && window.sionsGoBack(); }",null);
        } else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(audio != null) audio.destroy();
        if (tvServer != null) { tvServer.stop(); tvServer = null; }
        if(pendingFiles != null){pendingFiles.onReceiveValue(null);pendingFiles = null;}
        if(webView != null){webView.destroy();webView = null;}
        super.onDestroy();
    }
}
