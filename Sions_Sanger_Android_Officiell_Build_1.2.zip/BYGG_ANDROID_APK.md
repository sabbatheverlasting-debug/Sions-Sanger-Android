# Sions Sånger – riktig Android-byggning

Den tidigare versionen byggdes genom att skriva APK-formatet manuellt. Den här versionen är istället ett Android Studio-projekt som använder Googles Android Gradle Plugin och bygger en normal, installerbar APK.

## Bygg med Android Studio (Windows/macOS/Linux)
1. Packa upp ZIP-filen.
2. Öppna mappen i Android Studio.
3. Godkänn installation av efterfrågad Android SDK.
4. Välj **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Hämta `app/build/outputs/apk/debug/app-debug.apk` och överför den till telefonen.

## Bygg via GitHub (utan egen dator)
1. Skapa ett privat eller offentligt GitHub-förråd.
2. Ladda upp innehållet i den uppackade projektmappen, **inklusive `.github`-mappen**, till förrådets rot. Den nedladdade ZIP-filen kan inte köras direkt av GitHub Actions utan att först laddas upp som källfiler.
3. Öppna fliken **Actions**, välj **Bygg Sions Sånger APK**, tryck **Run workflow**.
4. När byggningen är grön, öppna körningen och ladda ned artefakten **Sions-Sanger-Android-APK**.
5. Packa upp artefaktens ZIP och installera `app-debug.apk` på Android.

## Viktigt
Det här källprojektet har inte byggts eller installerats i den här ChatGPT-miljön. Det är därför ännu inte bekräftat att APK-filen går att installera på din telefon. Inga originaltexter har ändrats.

Innehåll: 62 historiskt inskannade sångtexter; sökning efter nummer, ord och fraser; sånglista; favoriter; lokal JSON-import och export.
