SIONS SÅNGER – ANDROID STUDIO-PROJEKT

Det här är källkoden till en Android-app som kör Sions Sånger lokalt,
utan internetanslutning. 62 sånger finns redan inlästa.

För att skapa en installationsbar APK:
1. Öppna katalogen Sions_Sanger_Android_Studio i Android Studio.
2. Låt Android Studio synkronisera Gradle och hämta nödvändiga byggverktyg.
3. Välj Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Installera APK-filen på telefonen.

OBS: APK har inte kunnat byggas eller installeras i den här miljön,
eftersom Android SDK och Gradle inte finns tillgängliga. Projektet
levereras som källkod, inte som en testad eller signerad APK.

Appen använder Androids systemfilväljare för JSON-import och export.
För att lägga till fler sånger: Mer > Importera JSON-filer.

App-id: se.sionssanger.app
Android: minSdk 24, targetSdk 35, Java 17.
